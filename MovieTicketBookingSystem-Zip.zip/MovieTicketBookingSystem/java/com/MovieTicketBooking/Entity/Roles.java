package com.MovieTicketBooking.Entity;

public enum Roles {


	USER,
	
	ADMIN

}
