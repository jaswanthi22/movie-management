package com.MovieTicketBooking.Entity;

import java.time.LocalDateTime;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

@Entity
public class Seats {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	
	private long seatId;

	@Column(nullable = true)
	private int TotalSeatCount;
	
	private int SeatNumber;
	
	private boolean seatStatus;
	
	private LocalDateTime createdAt;
	
	private LocalDateTime updatedAt;
	
	public long getSeatId() {
		return seatId;
	}

	public void setSeatId(long seatId) {
		this.seatId = seatId;
	}

	public int getTotalSeatCount() {
		return TotalSeatCount;
	}

	public void setTotalSeatCount(int totalSeatCount) {
		TotalSeatCount = totalSeatCount;
	}

	public int getSeatNumber() {
		return SeatNumber;
	}

	public void setSeatNumber(int seatNumber) {
		SeatNumber = seatNumber;
	}

	public boolean isSeatStatus() {
		return seatStatus;
	}

	public void setSeatStatus(boolean seatStatus) {
		this.seatStatus = seatStatus;
	}

	public LocalDateTime getCreatedAt() {
		return createdAt;
	}

	public void setCreatedAt(LocalDateTime createdAt) {
		this.createdAt = createdAt;
	}

	public LocalDateTime getUpdatedAt() {
		return updatedAt;
	}

	public void setUpdatedAt(LocalDateTime updatedAt) {
		this.updatedAt = updatedAt;
	}
	
	
}
