package com.MovieTicketBooking.Entity;

import java.time.LocalDateTime;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToMany;
import jakarta.persistence.OneToOne;

@Entity
public class Theater {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private long theaterId;
	
	@Column(nullable = false)
	private String theaterName;
//	
//	@Column(nullable = false)
//	private String cityName;
	
	@Column(nullable = false)
	private int seatCapacity;
	
	@Column(nullable = false)
	private int numberOfShows;
	
	@Column(nullable = false)
	private String theaterImage1;
	
	@Column(nullable = true)
	private String theaterImage2;
	
	@Column(nullable = false)
	private String theaterImage3;
	  
	@ManyToOne
	@JoinColumn(name = "cityid") 
	private City city;
	
	@OneToOne
	@JoinColumn(name = "theaterAddressId")
	private TheaterAddress theaterAddress;
	
	@OneToOne(optional = true)
	@JoinColumn(name = "movieId")
	private Movies currentPlayingmovie;
	
	private LocalDateTime createdAt;
	
	
	public LocalDateTime getCreatedAt() {
		return createdAt;
	}

	public void setCreatedAt(LocalDateTime createdAt) {
		this.createdAt = createdAt;
	}

	private LocalDateTime updatedAt;
	
	public LocalDateTime getUpdatedAt() {
		return updatedAt;
	}

	public void setUpdatedAt(LocalDateTime updatedAt) {
		this.updatedAt = updatedAt;
	}
	

	public long getTheaterId() {
		return theaterId;
	}

	public void setTheaterId(long theaterId) {
		this.theaterId = theaterId;
	}

	public String getTheaterName() {
		return theaterName;
	}

	public void setTheaterName(String theaterName) {
		this.theaterName = theaterName;
	}

//	public String getCityName() {
//		return cityName;
//	}
//
//	public void setCityName(String cityName) {
//		this.cityName = cityName;
//	}

	public int getSeatCapacity() {
		return seatCapacity;
	}

	public void setSeatCapacity(int seatCapacity) {
		this.seatCapacity = seatCapacity;
	}

	public int getNumberOfShows() {
		return numberOfShows;
	}

	public void setNumberOfShows(int numberOfShows) {
		this.numberOfShows = numberOfShows;
	}

	public String getTheaterImage1() {
		return theaterImage1;
	}

	public void setTheaterImage1(String theaterImage1) {
		this.theaterImage1 = theaterImage1;
	}

	public String getTheaterImage2() {
		return theaterImage2;
	}

	public void setTheaterImage2(String theaterImage2) {
		this.theaterImage2 = theaterImage2;
	}

	public String getTheaterImage3() {
		return theaterImage3;
	}

	public void setTheaterImage3(String theaterImage3) {
		this.theaterImage3 = theaterImage3;
	}

	public TheaterAddress getTheaterAddress() {
		return theaterAddress;
	}

	public void setTheaterAddress(TheaterAddress theaterAddress) {
		this.theaterAddress = theaterAddress;
	}

	public City getCity() {
		return city;
	}

	public void setCity(City city) {
		this.city = city;
	}

	public Movies getCurrentPlayingmovie() {
		return currentPlayingmovie;
	}

	public void setCurrentPlayingmovie(Movies currentPlayingmovie) {
		this.currentPlayingmovie = currentPlayingmovie;
	}

	
	
	
	
	

}
