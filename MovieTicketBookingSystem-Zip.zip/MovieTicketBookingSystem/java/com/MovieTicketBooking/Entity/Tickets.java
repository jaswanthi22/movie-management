package com.MovieTicketBooking.Entity;

public class Tickets {

}
