package com.MovieTicketBooking.Entity;

import java.time.LocalDateTime;


import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;

@Entity
public class TheaterMovie {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private long theaterMovieId;
	
	@ManyToOne
	@JoinColumn(name = "theaterId")
	private Theater theater;
	
	@ManyToOne
	@JoinColumn(name ="movieId")
	private Movies movies;
	
	private LocalDateTime createdBy;
	
	private LocalDateTime updatedBy;

	public long getTheaterMovieId() {
		return theaterMovieId;
	}

	public void setTheaterMovieId(long theaterMovieId) {
		this.theaterMovieId = theaterMovieId;
	}


	public LocalDateTime getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(LocalDateTime createdBy) {
		this.createdBy = createdBy;
	}

	public LocalDateTime getUpdatedBy() {
		return updatedBy;
	}

	public void setUpdatedBy(LocalDateTime updatedBy) {
		this.updatedBy = updatedBy;
	}


	
	
}

