package com.MovieTicketBooking.Entity;

import java.time.LocalDateTime;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

@Entity
public class TheaterAddress {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private long theaterAddressId;
	
	@Column(nullable = false)
	private String stateName;
	
	@Column(nullable = false)
	private String districtName;
	
	
	@Column(nullable = true)
	private long streetNumber;
	
	@Column(nullable = true)
	private String streetName;
	
	@Column(nullable = true)
	private long postalCode;
	
	private LocalDateTime createdAt;
	
	private LocalDateTime updatedAt;
	
	public LocalDateTime getCreatedAt() {
		return createdAt;
	}

	public void setCreatedAt(LocalDateTime createdAt) {
		this.createdAt = createdAt;
	}


	
	public LocalDateTime getUpdatedAt() {
		return updatedAt;
	}

	public void setUpdatedAt(LocalDateTime updatedAt) {
		this.updatedAt = updatedAt;
	}
	

	public long getTheaterAddressId() {
		return theaterAddressId;
	}

	public void setTheaterAddressId(long theaterAddressId) {
		this.theaterAddressId = theaterAddressId;
	}

	public String getStateName() {
		return stateName;
	}

	public void setStateName(String stateName) {
		this.stateName = stateName;
	}

	public String getDistrictName() {
		return districtName;
	}

	public void setDistrictName(String districtName) {
		this.districtName = districtName;
	}


	public long getStreetNumber() {
		return streetNumber;
	}

	public void setStreetNumber(long streetNumber) {
		this.streetNumber = streetNumber;
	}

	public String getStreetName() {
		return streetName;
	}

	public void setStreetName(String streetName) {
		this.streetName = streetName;
	}

	public long getPostalCode() {
		return postalCode;
	}

	public void setPostalCode(long postalCode) {
		this.postalCode = postalCode;
	}
	
	
	
	
	
	
	
	
	

}
