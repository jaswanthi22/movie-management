package com.MovieTicketBooking.Entity;

import java.time.LocalDateTime;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

@Entity
public class Movies {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private long movieId;
	
	private String movieName;
	
	private String DirectorName;
	
	private String movieImage1;
	
	private String movieImage2;
	
	private String movieImage3;
	
	private int movieRating;
	
	private String movieGenre;
	
	//language1

	private LocalDateTime createdAt;
	
	private LocalDateTime updatedAt;
	
	
	public LocalDateTime getCreatedAt() {
		return createdAt;
	}

	public void setCreatedAt(LocalDateTime createdAt) {
		this.createdAt = createdAt;
	}

	public LocalDateTime getUpdatedAt() {
		return updatedAt;
	}

	public void setUpdatedAt(LocalDateTime updatedAt) {
		this.updatedAt = updatedAt;
	}
	
	public long getMovieId() {
		return movieId;
	}

	public void setMovieId(long movieId) {
		this.movieId = movieId;
	}

	public String getMovieName() {
		return movieName;
	}

	public void setMovieName(String movieName) {
		this.movieName = movieName;
	}

	public String getDirectorName() {
		return DirectorName;
	}

	public void setDirectorName(String directorName) {
		DirectorName = directorName;
	}

	public String getMovieImage1() {
		return movieImage1;
	}

	public void setMovieImage1(String movieImage1) {
		this.movieImage1 = movieImage1;
	}

	public String getMovieImage2() {
		return movieImage2;
	}

	public void setMovieImage2(String movieImage2) {
		this.movieImage2 = movieImage2;
	}

	public String getMovieImage3() {
		return movieImage3;
	}

	public void setMovieImage3(String movieImage3) {
		this.movieImage3 = movieImage3;
	}

	public int getMovieRating() {
		return movieRating;
	}

	public void setMovieRating(int movieRating) {
		this.movieRating = movieRating;
	}

	public String getMovieGenre() {
		return movieGenre;
	}

	public void setMovieGenre(String movieGenre) {
		this.movieGenre = movieGenre;
	}
	
	
	
	

}
