package com.MovieTicketBooking.Entity;

import java.time.LocalDateTime;
import java.time.LocalTime;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;

@Entity
public class Shows {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int showId;
	
	private LocalTime firstShowTiming;
	
	private LocalTime secondShowTiming;
	
	private LocalTime thirdShowTiming;

	private LocalTime fourtShowTiming;
	
	private LocalTime fithShowTiming;
	
	@ManyToOne
	@JoinColumn(name = "theaterId")
	private Theater theater;
	
	private LocalDateTime createdAt;
	
	public LocalDateTime getCreatedAt() {
		return createdAt;
	}

	public void setCreatedAt(LocalDateTime createdAt) {
		this.createdAt = createdAt;
	}

	private LocalDateTime updatedAt;
	
	public LocalDateTime getUpdatedAt() {
		return updatedAt;
	}

	public void setUpdatedAt(LocalDateTime updatedAt) {
		this.updatedAt = updatedAt;
	}
	

	public int getShowId() {
		return showId;
	}

	public void setShowId(int showId) {
		this.showId = showId;
	}

	public LocalTime getFirstShowTiming() {
		return firstShowTiming;
	}

	public void setFirstShowTiming(LocalTime firstShowTiming) {
		this.firstShowTiming = firstShowTiming;
	}

	public LocalTime getSecondShowTiming() {
		return secondShowTiming;
	}

	public void setSecondShowTiming(LocalTime secondShowTiming) {
		this.secondShowTiming = secondShowTiming;
	}

	public LocalTime getThirdShowTiming() {
		return thirdShowTiming;
	}

	public void setThirdShowTiming(LocalTime thirdShowTiming) {
		this.thirdShowTiming = thirdShowTiming;
	}

	public LocalTime getFourtShowTiming() {
		return fourtShowTiming;
	}

	public void setFourtShowTiming(LocalTime fourtShowTiming) {
		this.fourtShowTiming = fourtShowTiming;
	}

	public LocalTime getFithShowTiming() {
		return fithShowTiming;
	}

	public void setFithShowTiming(LocalTime fithShowTiming) {
		this.fithShowTiming = fithShowTiming;
	}

	public Theater getTheater() {
		return theater;
	}

	public void setTheater(Theater theater) {
		this.theater = theater;
	}
	
	
	
}
