package com.MovieTicketBooking.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.MovieTicketBooking.DTO.MessageInfo;
import com.MovieTicketBooking.Entity.City;
import com.MovieTicketBooking.ServiceInterface.CityServiceImplementation;

@RestController
public class CityController {
	
	@Autowired
	CityServiceImplementation cityServiceImplementation;
	
	@PostMapping("/city")
	public ResponseEntity<MessageInfo> addCityList(@RequestBody City city){
		
		return new ResponseEntity<MessageInfo>(cityServiceImplementation.addCityInformation(city), HttpStatus.ACCEPTED);
		
		
	}
	@GetMapping("/city")
	public ResponseEntity<List<City>> getCityList(@RequestBody City city){
		
		return new ResponseEntity<List<City>>(cityServiceImplementation.showListOfCity(), HttpStatus.ACCEPTED);
		
		
	}
	
	

}
