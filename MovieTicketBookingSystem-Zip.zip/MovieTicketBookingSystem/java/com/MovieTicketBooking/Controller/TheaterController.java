package com.MovieTicketBooking.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.MovieTicketBooking.DTO.MessageInfo;
import com.MovieTicketBooking.DTO.TheaterDTO;
import com.MovieTicketBooking.Entity.City;
import com.MovieTicketBooking.Entity.Theater;
import com.MovieTicketBooking.Entity.TheaterAddress;
import com.MovieTicketBooking.ServiceInterface.TheraterServiceImplementation;

@RestController
public class TheaterController {
	
	@Autowired
	TheraterServiceImplementation theraterServiceImplementation;
	
			
	@PostMapping("/theater/{cityId}")
	public ResponseEntity<MessageInfo> addTheaterDetails(@RequestBody TheaterDTO theaterDTO,@PathVariable Long cityId){
		
		return new ResponseEntity<MessageInfo>(theraterServiceImplementation.AddTheater(theaterDTO, cityId), HttpStatus.ACCEPTED);
	}
	
	@GetMapping("/theater/{cityId}")
	public ResponseEntity<List<Theater>> viewListOfTheatersBasedonCity(@PathVariable Long cityId){
		
		return new ResponseEntity<List<Theater>>(theraterServiceImplementation.ListOfTheaterBasedOnCity(cityId), HttpStatus.ACCEPTED);
	}
 
}
