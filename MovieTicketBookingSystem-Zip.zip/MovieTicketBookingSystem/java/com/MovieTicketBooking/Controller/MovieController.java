package com.MovieTicketBooking.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.MovieTicketBooking.DTO.MessageInfo;
import com.MovieTicketBooking.Entity.Movies;
import com.MovieTicketBooking.ServiceInterface.MovieServiceImplementation;

@RestController
public class MovieController {

	@Autowired
	MovieServiceImplementation movieServiceImplementation;
	
	
	@GetMapping("/movie")
	public ResponseEntity<List<Movies>> ListofMovies(){
		
		return new ResponseEntity<List<Movies>>(movieServiceImplementation.showListOfMovies(),HttpStatus.ACCEPTED);
	}
	
	@PostMapping("/movie")
	public ResponseEntity<MessageInfo> addMovies(@RequestBody Movies movies){
		
		return new ResponseEntity<MessageInfo>(movieServiceImplementation.addMoviesList(movies),HttpStatus.ACCEPTED);
	}
	
	
}
