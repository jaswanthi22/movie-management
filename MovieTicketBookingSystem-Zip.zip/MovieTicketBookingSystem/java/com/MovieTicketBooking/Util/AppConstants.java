package com.MovieTicketBooking.Util;

public interface AppConstants {
	
	public final static  String  MovieListNnullException = "The Movie List is null Present in the database";

	public final static  String  MovieDataUploadedSuccessfully = "The Movie List was added successfully to the database";

	public final static  String  CityDataUploadedSuccessfully = "The City List was added successfully to the database";

	public final static  String  CityDataNullException = "The City List is null its not present in the database";

	public final static  String  CityIdNoutFoundException = "The Entered CityId is not found Please restart the page";

	public final static  String  CityDataNotFound = "The Entered CityId is not found try After Sometime";

	public final static  String  SelectedCityTheaterListEmpty = "Your selected city don't have any theaters please select any other City";
	
	public final static  String  TheaterListNullException = "Your selected city don't have any theaters please select any other City";
	
	

}

