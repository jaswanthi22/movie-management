package com.MovieTicketBooking.DTO;

import java.time.LocalDateTime;

import com.MovieTicketBooking.Entity.TheaterAddress;

public class TheaterDTO {
	
    private String theaterName;
    private int seatCapacity;
    private int numberOfShows;
    private String theaterImage1;
    private String theaterImage2;
    private String theaterImage3;
    private String stateName;
    private String districtName;
    private long streetNumber;
    private String streetName;
    private long postalCode;
    private LocalDateTime createdAt;
    private LocalDateTime updatedAt;

    // Getters and Setters

    public String getTheaterName() {
        return theaterName;
    }

    public void setTheaterName(String theaterName) {
        this.theaterName = theaterName;
    }

    public int getSeatCapacity() {
        return seatCapacity;
    }

    public void setSeatCapacity(int seatCapacity) {
        this.seatCapacity = seatCapacity;
    }

    public int getNumberOfShows() {
        return numberOfShows;
    }

    public void setNumberOfShows(int numberOfShows) {
        this.numberOfShows = numberOfShows;
    }

    public String getTheaterImage1() {
        return theaterImage1;
    }

    public void setTheaterImage1(String theaterImage1) {
        this.theaterImage1 = theaterImage1;
    }

    public String getTheaterImage2() {
        return theaterImage2;
    }

    public void setTheaterImage2(String theaterImage2) {
        this.theaterImage2 = theaterImage2;
    }

    public String getTheaterImage3() {
        return theaterImage3;
    }

    public void setTheaterImage3(String theaterImage3) {
        this.theaterImage3 = theaterImage3;
    }

    public String getStateName() {
        return stateName;
    }

    public void setStateName(String stateName) {
        this.stateName = stateName;
    }

    public String getDistrictName() {
        return districtName;
    }

    public void setDistrictName(String districtName) {
        this.districtName = districtName;
    }

    public long getStreetNumber() {
        return streetNumber;
    }

    public void setStreetNumber(long streetNumber) {
        this.streetNumber = streetNumber;
    }

    public String getStreetName() {
        return streetName;
    }

    public void setStreetName(String streetName) {
        this.streetName = streetName;
    }

    public long getPostalCode() {
        return postalCode;
    }

    public void setPostalCode(long postalCode) {
        this.postalCode = postalCode;
    }

    public LocalDateTime getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(LocalDateTime createdAt) {
        this.createdAt = createdAt;
    }

    public LocalDateTime getUpdatedAt() {
        return updatedAt;
    }

    public void setUpdatedAt(LocalDateTime updatedAt) {
        this.updatedAt = updatedAt;
    }

}
    
    
	