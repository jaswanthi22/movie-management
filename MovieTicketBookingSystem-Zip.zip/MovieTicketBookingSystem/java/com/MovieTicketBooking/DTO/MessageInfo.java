package com.MovieTicketBooking.DTO;

public class MessageInfo {
	
	public String message;

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public MessageInfo(String message) {
		super();
		this.message = message;
	}
	
	
	

}
