package com.MovieTicketBooking.DTO;

public class UserData {
	
	public long userId;
	
	public String userName;
	
	public String userEmailId;
	
	public String PhoneNumber;

	public UserData(long userId, String userName, String userEmailId, String phoneNumber) {
		super();
		this.userId = userId;
		this.userName = userName;
		this.userEmailId = userEmailId;
		PhoneNumber = phoneNumber;
	}
	
	

}
