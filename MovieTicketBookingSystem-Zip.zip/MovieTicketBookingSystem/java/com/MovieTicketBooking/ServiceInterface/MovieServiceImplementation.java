package com.MovieTicketBooking.ServiceInterface;

import java.time.LocalDateTime;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.MovieTicketBooking.DTO.MessageInfo;
import com.MovieTicketBooking.Entity.Movies;
import com.MovieTicketBooking.ExceptionHandling.MovieListNullException;
import com.MovieTicketBooking.Repository.MovieRepository;
import com.MovieTicketBooking.Util.AppConstants;

@Service
public class MovieServiceImplementation implements MovieServiceInterface{
	
	@Autowired
	MovieRepository movieRepository;

	@Override
	public List<Movies> showListOfMovies() {
		
		List<Movies> moviesList = movieRepository.findAll();
	    if (moviesList != null && !moviesList.isEmpty()) {
			return moviesList;
		}
		else {
			throw new MovieListNullException(AppConstants.MovieListNnullException);
		}
	}

	@Override
	public MessageInfo addMoviesList(Movies movies) {
		
		if(movies != null) {
			Movies movie = new Movies();
			
			movie.setMovieImage1(movies.getMovieImage1());
			movie.setMovieImage2(movies.getMovieImage2());
			movie.setMovieImage3(movies.getMovieImage3());
			movie.setMovieName(movies.getMovieName());
			movie.setMovieRating(movies.getMovieRating());
			movie.setDirectorName(movies.getDirectorName());
			movie.setMovieGenre(movies.getMovieGenre());
			movie.setCreatedAt(LocalDateTime.now());
			
			movieRepository.save(movie);
			
			return new MessageInfo(AppConstants.MovieDataUploadedSuccessfully);
			
		}
		else {
			throw new MovieListNullException(AppConstants.MovieListNnullException);
		}

	}
	
	

}
