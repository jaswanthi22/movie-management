package com.MovieTicketBooking.ServiceInterface;

import org.springframework.stereotype.Service;

@Service
public class UserServiceImplementation {

	
	
}
