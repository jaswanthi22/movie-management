package com.MovieTicketBooking.ServiceInterface;

import java.util.List;

import com.MovieTicketBooking.DTO.MessageInfo;
import com.MovieTicketBooking.DTO.TheaterDTO;
import com.MovieTicketBooking.Entity.Theater;

public interface TheaterServiceInterface {

	public MessageInfo AddTheater(TheaterDTO theaterDTO,Long cityId);
	
	public List<Theater> ListOfTheaterBasedOnCity(Long cityId);
}
