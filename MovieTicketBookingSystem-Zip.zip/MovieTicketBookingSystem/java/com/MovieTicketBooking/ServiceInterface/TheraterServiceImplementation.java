package com.MovieTicketBooking.ServiceInterface;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.MovieTicketBooking.DTO.MessageInfo;
import com.MovieTicketBooking.DTO.TheaterDTO;
import com.MovieTicketBooking.Entity.City;
import com.MovieTicketBooking.Entity.Theater;
import com.MovieTicketBooking.Entity.TheaterAddress;
import com.MovieTicketBooking.ExceptionHandling.CityIdNotFoundException;
import com.MovieTicketBooking.ExceptionHandling.TheaterListNullException;
import com.MovieTicketBooking.Repository.CityRepository;
import com.MovieTicketBooking.Repository.TheaterAddressRepository;
import com.MovieTicketBooking.Repository.TheaterMovieRepository;
import com.MovieTicketBooking.Repository.TheaterRepository;
import com.MovieTicketBooking.Util.AppConstants;

@Service
public class TheraterServiceImplementation implements TheaterServiceInterface{
	
	@Autowired
	TheaterRepository theaterRepository;
	
	@Autowired
	TheaterAddressRepository addressRepository;

	@Autowired
	CityRepository cityRepository;
	
	@Autowired
	TheaterMovieRepository theaterMovieRepository;

	@Override
	public MessageInfo AddTheater(TheaterDTO theaterDTO ,Long cityId) {
		
		Optional<City> city = cityRepository.findById(cityId);
		
		if(city.isPresent()) {
			
			Theater addTheater = new Theater();
			
			addTheater.setTheaterName(theaterDTO.getTheaterName());
			addTheater.setTheaterImage1(theaterDTO.getTheaterImage1());
			addTheater.setTheaterImage2(theaterDTO.getTheaterImage2());
			addTheater.setTheaterImage3(theaterDTO.getTheaterImage3());
			addTheater.setSeatCapacity(theaterDTO.getSeatCapacity());
			addTheater.setCity(city.get());
			addTheater.setCreatedAt(LocalDateTime.now());
			addTheater.setCurrentPlayingmovie(null);
			addTheater.setNumberOfShows(theaterDTO.getNumberOfShows());
			//calling the method to save the theateraddress seperately
			TheaterAddress theaterAddress = addTheaterAddressInfo(theaterDTO);
			//adding the theateraddressId to theater Entity
			addTheater.setTheaterAddress(theaterAddress);
			
			theaterRepository.save(addTheater);
			
			return new MessageInfo("Your Theater Details were successfully added to the database");
			
		}
		else {
			throw new CityIdNotFoundException(AppConstants.CityIdNoutFoundException);
		}

	}

	//Method for adding the address of the theater to the database
	
	public TheaterAddress addTheaterAddressInfo(TheaterDTO theaterDTO) {
		
		TheaterAddress address = new TheaterAddress();
		
		address.setDistrictName(theaterDTO.getDistrictName());
		address.setStateName(theaterDTO.getStateName());
		address.setStreetNumber(theaterDTO.getStreetNumber());
		address.setPostalCode(theaterDTO.getStreetNumber());
		address.setCreatedAt(LocalDateTime.now());
		
		addressRepository.save(address);  
		
		return address;
		
	}

	@Override
	public List<Theater> ListOfTheaterBasedOnCity(Long cityId) {
		
		Optional<City> city = cityRepository.findById(cityId);
		
		if(city.isPresent()) {
			List<Theater> theaters = theaterRepository.findByCity(city.get());
			
			if(theaters.isEmpty()) {
				
				throw new TheaterListNullException(AppConstants.TheaterListNullException);
			}
			else {
				return theaters;
			}
			
		}
		else {
			throw new CityIdNotFoundException(AppConstants.CityDataNotFound);
		}
		
	}
	
	
	
	
	
	
	

}
