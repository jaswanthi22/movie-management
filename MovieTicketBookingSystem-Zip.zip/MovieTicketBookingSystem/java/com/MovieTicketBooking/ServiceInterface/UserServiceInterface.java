package com.MovieTicketBooking.ServiceInterface;

public interface UserServiceInterface {
	

}
