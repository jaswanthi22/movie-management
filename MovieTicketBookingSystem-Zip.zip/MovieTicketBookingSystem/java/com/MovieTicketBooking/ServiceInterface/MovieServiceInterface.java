package com.MovieTicketBooking.ServiceInterface;

import java.util.List;

import com.MovieTicketBooking.DTO.MessageInfo;
import com.MovieTicketBooking.Entity.Movies;

public interface MovieServiceInterface {
	
	public List<Movies> showListOfMovies();
	
	public MessageInfo addMoviesList(Movies movies);

}
