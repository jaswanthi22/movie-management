package com.MovieTicketBooking.ServiceInterface;

public interface ShowServiceInterface {

}
