package com.MovieTicketBooking.ServiceInterface;

import java.time.LocalDateTime;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.MovieTicketBooking.DTO.MessageInfo;
import com.MovieTicketBooking.Entity.City;
import com.MovieTicketBooking.ExceptionHandling.CityListNotNullException;
import com.MovieTicketBooking.Repository.CityRepository;
import com.MovieTicketBooking.Util.AppConstants;

@Service
public class CityServiceImplementation implements CityServiceInterface  {
	
	@Autowired
	CityRepository cityRepository;

	@Override
	public MessageInfo addCityInformation(City city) {
		
		City addCity = new City();
		
		addCity.setCityName(city.getCityName());
		addCity.setPincode(city.getPincode());
		addCity.setLattitude(city.getLattitude());
		addCity.setLongitude(city.getLongitude());
		addCity.setCreatedAt(LocalDateTime.now());
		
		cityRepository.save(addCity);
		
		return new MessageInfo(AppConstants.CityDataUploadedSuccessfully);
	}
	
	public List<City> showListOfCity(){
		
		List<City> getCityList = cityRepository.findAll();
		
		if(getCityList != null) {
			
			return getCityList;
			
		}
		else {
			throw new CityListNotNullException(AppConstants.CityDataNullException);
		}
		
	}


	

}
