package com.MovieTicketBooking.ServiceInterface;

import java.util.List;

import com.MovieTicketBooking.DTO.MessageInfo;
import com.MovieTicketBooking.Entity.City;

public interface CityServiceInterface {

	public MessageInfo addCityInformation(City city);
	
	public List<City> showListOfCity();
}
