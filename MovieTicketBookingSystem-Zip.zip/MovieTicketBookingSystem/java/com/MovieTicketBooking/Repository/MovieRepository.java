package com.MovieTicketBooking.Repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.MovieTicketBooking.Entity.Movies;

public interface MovieRepository extends JpaRepository<Movies, Long>{

}
