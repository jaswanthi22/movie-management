package com.MovieTicketBooking.Repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.MovieTicketBooking.Entity.City;

public interface CityRepository extends JpaRepository<City,Long>{

}
