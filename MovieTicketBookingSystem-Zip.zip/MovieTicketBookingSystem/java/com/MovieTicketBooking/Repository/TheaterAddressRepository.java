package com.MovieTicketBooking.Repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.MovieTicketBooking.Entity.TheaterAddress;

public interface TheaterAddressRepository extends JpaRepository<TheaterAddress, Long>{

}
