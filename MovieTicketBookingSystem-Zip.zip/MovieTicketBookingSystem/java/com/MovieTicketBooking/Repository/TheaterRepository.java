package com.MovieTicketBooking.Repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.MovieTicketBooking.Entity.City;
import com.MovieTicketBooking.Entity.Theater;

public interface TheaterRepository extends JpaRepository<Theater, Long> {
	
	public  List<Theater> findByCity(City city);

}
