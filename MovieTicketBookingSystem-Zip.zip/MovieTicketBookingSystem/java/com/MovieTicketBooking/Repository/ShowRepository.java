package com.MovieTicketBooking.Repository;

public class ShowRepository {

}
