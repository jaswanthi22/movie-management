package com.MovieTicketBooking.ExceptionHandling;

public class CityIdNotFoundException extends RuntimeException{
	
	public String message;

	public CityIdNotFoundException(String message) {
		super(message);
		this.message = message;
	}

	

}
