package com.MovieTicketBooking.ExceptionHandling;

import java.time.LocalDateTime;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

@RestControllerAdvice
public class GlobalExceptionHandler {

	@ExceptionHandler(MovieListNullException.class)
	public ResponseEntity<ErrorInfo> MovieListNullException(MovieListNullException exception){
		ErrorInfo errorInfo = new ErrorInfo();
		errorInfo.setErrorMessage(exception.getMessage());
		errorInfo.setStatus(HttpStatus.BAD_REQUEST.toString());
		errorInfo.setLocalDateTime(LocalDateTime.now());	
		return new ResponseEntity<ErrorInfo>(errorInfo, HttpStatus.BAD_REQUEST);
		
	}
	
	@ExceptionHandler(CityListNotNullException.class)
	public ResponseEntity<ErrorInfo> CityListNullException(CityListNotNullException exception){
		ErrorInfo errorInfo = new ErrorInfo();
		errorInfo.setErrorMessage(exception.getMessage());
		errorInfo.setStatus(HttpStatus.BAD_REQUEST.toString());
		errorInfo.setLocalDateTime(LocalDateTime.now());	
		return new ResponseEntity<ErrorInfo>(errorInfo, HttpStatus.BAD_REQUEST);
		
	}
	
	@ExceptionHandler(TheaterListNullException.class)
	public ResponseEntity<ErrorInfo> TheaterListNullException(TheaterListNullException exception){
		ErrorInfo errorInfo = new ErrorInfo();
		errorInfo.setErrorMessage(exception.getMessage());
		errorInfo.setStatus(HttpStatus.BAD_REQUEST.toString());
		errorInfo.setLocalDateTime(LocalDateTime.now());	
		return new ResponseEntity<ErrorInfo>(errorInfo, HttpStatus.BAD_REQUEST);
		
	}
	
	@ExceptionHandler(CityIdNotFoundException.class)
	public ResponseEntity<ErrorInfo> CityIdNotFoundException(CityIdNotFoundException exception){
		ErrorInfo errorInfo = new ErrorInfo();
		errorInfo.setErrorMessage(exception.getMessage());
		errorInfo.setStatus(HttpStatus.BAD_REQUEST.toString());
		errorInfo.setLocalDateTime(LocalDateTime.now());
		
		return new ResponseEntity<ErrorInfo>(errorInfo, HttpStatus.BAD_REQUEST);
		
	}
	
	
	
	
}
