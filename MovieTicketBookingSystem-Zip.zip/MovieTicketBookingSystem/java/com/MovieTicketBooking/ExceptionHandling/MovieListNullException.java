package com.MovieTicketBooking.ExceptionHandling;

public class MovieListNullException extends RuntimeException{
	
	public String message;

	public MovieListNullException(String message) {
		super(message);
		this.message = message;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}
	
	
	
	
}
