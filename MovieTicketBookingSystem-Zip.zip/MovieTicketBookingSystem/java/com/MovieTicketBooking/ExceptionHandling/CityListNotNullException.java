package com.MovieTicketBooking.ExceptionHandling;

public class CityListNotNullException extends RuntimeException{
	
	public String message;

	public CityListNotNullException(String message) {
		super(message);
		this.message = message;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}
	
	
}
