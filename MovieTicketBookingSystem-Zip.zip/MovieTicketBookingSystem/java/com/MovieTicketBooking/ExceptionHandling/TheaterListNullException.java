package com.MovieTicketBooking.ExceptionHandling;

public class TheaterListNullException extends RuntimeException{
	
	public String message;

	public TheaterListNullException(String message) {
		super(message);
		this.message = message;
	}

	public String getMessage() {
		return message;
	}

	public String setMessage(String message) {
		
		return message;
	}

	
	

}
